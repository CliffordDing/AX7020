#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <linux/types.h>
#include <linux/videodev2.h>

#include "v4l2cap.h"
#include "v4l2_helper.h"

#define  TRUE	1
#define  FALSE	0

#define FILE_VIDEO 	"/dev/video0"
#define BMP      	"image_bmp.bmp"
#define YUV			"image_yuv.yuv"

#define  IMAGEWIDTH    1920
#define  IMAGEHEIGHT   1080
unsigned char frame_buffer[IMAGEWIDTH*IMAGEHEIGHT*3];
int v4l2_capture2(struct v4l2_dev *dev)
{
    int i;
    int ret;
    for (i = 0; i < BUFFER_CNT; ++i)  {
        struct v4l2_buffer buffer;
        memset(&buffer, 0, sizeof(buffer));
        buffer.type =V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buffer.memory = V4L2_MEMORY_MMAP;
        buffer.index = i;
        if (-1 == ioctl (dev->fd, VIDIOC_QUERYBUF, &buffer)) {
            perror("VIDIOC_QUERYBUF");
            exit(EXIT_FAILURE);
        }

        dev->vid_buf[i].v4l2_buff_length=buffer.length;

        /* remember for munmap() */
        dev->vid_buf[i].v4l2_buff = mmap(NULL,buffer.length, PROT_READ|PROT_WRITE, MAP_SHARED,dev->fd, buffer.m.offset);

        /* If you do not exit here you should unmap() and free()
        the buffers mapped so far. */

        ASSERT(MAP_FAILED == dev->vid_buf[i].v4l2_buff , "mmap failed ");
        dev->vid_buf[i].index = i;

    }


    /* Assigning buffer index and set exported buff handle */
    for(i=0;i<BUFFER_CNT;i++) {
        v4l2_queue_buffer(dev,&(dev->vid_buf[i]));
    }

    /* Start streaming */
    ret = v4l2_device_on(dev);
    ASSERT (ret < 0, "v4l2_device_on [video_in] failed %d \n",ret);

#ifdef DEBUG_MODE
    printf("Video Capture Pipeline started\n");
#endif
    struct buffer *b;
    b = v4l2_dequeue_buffer(dev,dev->vid_buf);
}

void yuyv_2_rgb888(int width,int height,void * src,void *dst)
{
    int i,j;
    unsigned char y1,y2,u,v;
    int r1,g1,b1,r2,g2,b2;
    char * pointer;
    int width_half;
    width_half = width / 2;
    
    pointer = (char *)src;

    for(i=0;i<height;i++)
    {
        for(j=0;j<width_half;j++)
        {
            y1 = *( pointer + (i*width_half+j)*4);
            u  = *( pointer + (i*width_half+j)*4 + 1);
            y2 = *( pointer + (i*width_half+j)*4 + 2);
            v  = *( pointer + (i*width_half+j)*4 + 3);

            r1 = y1 + 1.042*(v-128);
            g1 = y1 - 0.34414*(u-128) - 0.71414*(v-128);
            b1 = y1 + 1.772*(u-128);

            r2 = y2 + 1.042*(v-128);
            g2 = y2 - 0.34414*(u-128) - 0.71414*(v-128);
            b2 = y2 + 1.772*(u-128);

            if(r1>255)
                r1 = 255;
            else if(r1<0)
                r1 = 0;

            if(b1>255)
                b1 = 255;
            else if(b1<0)
                b1 = 0;

            if(g1>255)
                g1 = 255;
            else if(g1<0)
                g1 = 0;

            if(r2>255)
                r2 = 255;
            else if(r2<0)
                r2 = 0;

            if(b2>255)
                b2 = 255;
            else if(b2<0)
                b2 = 0;

            if(g2>255)
                g2 = 255;
            else if(g2<0)
                g2 = 0;

            *((char *)dst + ((height-1-i)*width_half+j)*6    ) = (unsigned char)b1;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 1) = (unsigned char)g1;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 2) = (unsigned char)r1;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 3) = (unsigned char)b2;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 4) = (unsigned char)g2;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 5) = (unsigned char)r2;
        }
    }
}

void xrgb8888_2_rgb888(int width,int height,void * src,void *dst)
{
    int i,j;
    char * pointer;
    pointer = (char *)src;
    for(i=0;i<height;i++)
    {
        for(j=0;j<width;j++)
        {

            *((char *)dst + ((height-1-i)*width+j)*3    ) = *( pointer + (i*width+j)*4 + 0);
            *((char *)dst + ((height-1-i)*width+j)*3 + 1) = *( pointer + (i*width+j)*4 + 1);
            *((char *)dst + ((height-1-i)*width+j)*3 + 2) = *( pointer + (i*width+j)*4 + 2);

        }
    }
}

void ycbcr_2_rgb888(int width,int height,void * src,void *dst)
{
    int i,j;
    char y1,y2,u,v;
    int r1,g1,b1,r2,g2,b2;
    char * pointer;
    int width_half;
    width_half = width / 2;

    pointer = (char *)src;

    for(i=0;i<height;i++)
    {
        for(j=0;j<width_half;j++)
        {
            y1 = *( pointer + (i*width_half+j)*4 + 1);
            u  = *( pointer + (i*width_half+j)*4 + 0);
            y2 = *( pointer + (i*width_half+j)*4 + 3);
            v  = *( pointer + (i*width_half+j)*4 + 2);

            r1 = 1.164 * (y1 - 16) + 1.793*(v-128);
            g1 = 1.164 * (y1 - 16) - 0.213*(u-128) - 0.534*(v-128);
            b1 = 1.164 * (y1 - 16) + 2.155*(u-128);

            r2 = 1.164 * (y2 - 16) + 1.793*(v-128);
            g2 = 1.164 * (y2 - 16) - 0.213*(u-128) - 0.534*(v-128);
            b2 = 1.164 * (y2 - 16) + 2.155*(u-128);

            if(r1>255)
                r1 = 255;
            else if(r1<0)
                r1 = 0;

            if(b1>255)
                b1 = 255;
            else if(b1<0)
                b1 = 0;

            if(g1>255)
                g1 = 255;
            else if(g1<0)
                g1 = 0;

            if(r2>255)
                r2 = 255;
            else if(r2<0)
                r2 = 0;

            if(b2>255)
                b2 = 255;
            else if(b2<0)
                b2 = 0;

            if(g2>255)
                g2 = 255;
            else if(g2<0)
                g2 = 0;

            *((char *)dst + ((height-1-i)*width_half+j)*6    ) = (unsigned char)b1;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 1) = (unsigned char)g1;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 2) = (unsigned char)r1;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 3) = (unsigned char)b2;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 4) = (unsigned char)g2;
            *((char *)dst + ((height-1-i)*width_half+j)*6 + 5) = (unsigned char)r2;
        }
    }
}


int main(void)
{

    FILE * fp1,* fp2;

    BITMAPFILEHEADER   bf;
    BITMAPINFOHEADER   bi;
    struct v4l2_dev dev;
    dev.buf_type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    dev.mem_type = V4L2_MEMORY_MMAP;
    dev.format.pixelformat = V4L2_PIX_FMT_YUYV;
    dev.format.width = IMAGEWIDTH;
    dev.format.height = IMAGEHEIGHT;
    dev.format.bytesperline = 2 * IMAGEWIDTH;
    dev.format.colorspace = V4L2_COLORSPACE_SRGB;
    if(v4l2_parse_node("vcap_ov5640_0 output 0",dev.devname))
    //if(v4l2_parse_node("uvcvideo",dev.devname))

    {
        printf("no dev find\n");
        return(FALSE);
    }
    printf("%s\n",dev.devname);
    v4l2_init(&dev, BUFFER_CNT);
    fp1 = fopen(BMP, "wb");
    if(!fp1)
    {
        printf("open "BMP"error\n");
        return(FALSE);
    }

    fp2 = fopen(YUV, "wb");
    if(!fp2)
    {
        printf("open "YUV" error\n");
        return(FALSE);
    }

    //Set BITMAPINFOHEADER
    bi.biSize = 40;
    bi.biWidth = IMAGEWIDTH;
    bi.biHeight = IMAGEHEIGHT;
    bi.biPlanes = 1;
    bi.biBitCount = 24;
    bi.biCompression = 0;
    bi.biSizeImage = IMAGEWIDTH*IMAGEHEIGHT*3;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    //Set BITMAPFILEHEADER
    bf.bfType = 0x4d42;
    bf.bfSize = 54 + bi.biSizeImage;
    bf.bfReserved = 0;
    bf.bfOffBits = 54;

    
    //v4l2_capture();
    v4l2_capture2(&dev);
    fwrite(dev.vid_buf[0].v4l2_buff, IMAGEWIDTH*IMAGEHEIGHT*2, 1, fp2);
    printf("saving "YUV" done!\n");
    
    yuyv_2_rgb888(IMAGEWIDTH,IMAGEHEIGHT,dev.vid_buf[0].v4l2_buff,frame_buffer);
    //xrgb8888_2_rgb888(IMAGEWIDTH,IMAGEHEIGHT,dev.vid_buf[1].v4l2_buff,frame_buffer);
    fwrite(&bf, 14, 1, fp1);
    fwrite(&bi, 40, 1, fp1);
    fwrite(frame_buffer, bi.biSizeImage, 1, fp1);
    printf("saving "BMP" done!\n");
    
    
    fclose(fp1);
    fclose(fp2);
    v4l2_device_off(&dev);
    return(TRUE);
}
